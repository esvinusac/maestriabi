import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline

class MultiplyColumns(BaseEstimator, TransformerMixin):

    #constructor: captar datos para configuración extenra.
    def __init__(self, by = 1, columns = None):
        self.by = by
        self.columns = columns

    #metodo para configurar valores internos.
    def fit(self, X, y = None):
        return self

    #metodo para aplicar transformacioes.
    def transform(self, X, y = None):
        X = X.copy()
        X[self.columns] = X[self.columns]*self.by
        return X
